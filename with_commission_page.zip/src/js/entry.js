
/*!*
 * ВНИМАНИЕ! Этот файл генерируется автоматически.
 * Любые изменения этого файла будут потеряны при следующей компиляции.
 * Любое изменение проекта без возможности компиляции ДОЛЬШЕ И ДОРОЖЕ в 2-5 раз.
 */

/* global require */

require('../blocks/counter/counter.js');
require('../blocks/modal/modal.js');
require('../blocks/nice-select/nice-select.js');
require('../blocks/side-menu/side-menu.js');
require('../blocks/sprite-svg/sprite-svg.js');
require('../blocks/timeline/timeline.js');
require('./script.js');
require('./dashboard.js');

/*!*
 * ВНИМАНИЕ! Этот файл генерируется автоматически.
 * Любые изменения этого файла будут потеряны при следующей компиляции.
 * Любое изменение проекта без возможности компиляции ДОЛЬШЕ И ДОРОЖЕ в 2-5 раз.
 */

