import svg4everybody from 'svg4everybody';

svg4everybody();
