import $ from 'jquery'
import 'bootstrap'

$(() => {
  const menuToggle = $('.page-header__menu-toggle')
  const mainNav = $('.main-nav')
  menuToggle.on('click', () => {
    mainNav.toggleClass('main-nav--visible')
  })

  $('.select').niceSelect()

  $('.side-menu .dropdown-menu').on('click', e => {
    e.stopPropagation()
  })

  // Bullets select on commission page
  const bulletsArr = document.querySelectorAll(
    '.commission-cards__bullets .bullet'
  )
  const commissionCards = document.querySelector('.commission-cards')

  const removeFilled = (bullets = bulletsArr) => {
    bullets.forEach(bullet => {
      bullet.classList.remove('filled')
    })
  }

  const scroll = position => {
    const target = document.querySelector(`[data-view='${position}']`)

    commissionCards.scrollTop = target.offsetTop - commissionCards.offsetTop
  }

  bulletsArr.forEach((bullet, index) => {
    bullet.dataset.position = index + 1

    bullet.addEventListener('click', e => {
      removeFilled()
      scroll(e.target.dataset.position)

      bullet.classList.add('filled')
    })
  })
})
