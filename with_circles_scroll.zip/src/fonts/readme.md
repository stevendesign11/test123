# Шрифты

Исходные файлы шрифтов. Упомяните их в `config.js` для копирования в папку сборки.

Пример секции в `config.js`:

```js
"addAssets": {
  "./src/fonts/open-sans-regular.woff2": "fonts/",
  "./src/fonts/open-sans-regular.woff": "fonts/",
},
```
