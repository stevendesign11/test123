import $ from 'jquery';

$(() => {
  $('.counter').on('click', '.counter-btn', (e) => {
    console.log('+');
    const btn = $(e.target);
    const counter = $(e.target).closest('.counter');
    const counterInput = $('.input', counter);
    if (btn.hasClass('dec')) {
      counterInput.val(Number(counterInput.val()) - 1);
    }
    if (btn.hasClass('inc')) {
      counterInput.val(Number(counterInput.val()) + 1);
    }
  });
});
