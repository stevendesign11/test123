import ApexCharts from 'apexcharts';

$(() => {
  const options = {
    chart: {
      height: 410,
      type: 'bar',
      stacked: true,
      toolbar: {
        tools: {
          download: true,
          selection: false,
          zoom: false,
          zoomin: false,
          zoomout: false,
          pan: false,
          reset: false
        }
      },
    },
    legend: {
      show: false,
    },
    tooltip: {
      shared: true
    },
    dataLabels: {
      enabled: false
    },
    series: [
      {
        name: 'Base Pay',
        data: [1800, 1900, 2000, 1800, 1500, 0, 0, 0, 0, 0]
      }, {
        name: 'Commission',
        data: [1940, 2040, 2140, 1940, 1600, 0, 0, 0, 0, 0]
      }, {
        name: 'Bonus',
        data: [600, 700, 750, 700, 600, 0, 0, 0, 0, 0]
      },
      {
        name: 'empty',
        data: [0, 0, 0, 0, 0, 3000, 3000, 3000, 3000, 3000]
      }
    ],
    colors: ['#002d60', '#0f93f5', '#48ecb0', '#f7f9fa'],
    xaxis: {
      categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
    }
  };

  const chart = new ApexCharts(document.querySelector('#chart-comp'), options);

  chart.render();

  $('.side-menu-toggle').on('click', () => {
    setTimeout(() => {
      chart.updateSeries(options.series);
    }, 3000);
  });
});
