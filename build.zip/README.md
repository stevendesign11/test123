https://vladchepel.github.io/venimir-dimov/build/index.html
https://vladchepel.github.io/venimir-dimov/build/index-2.html
https://vladchepel.github.io/venimir-dimov/build/dashboard.html
